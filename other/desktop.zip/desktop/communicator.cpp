#include "communicator.h"

Communicator::Communicator(QObject *parent) :
    QObject(parent)
{
}
