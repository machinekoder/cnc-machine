/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.0.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "codeeditor.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionLoad;
    QAction *action_About;
    QAction *action_Settings;
    QAction *action_Reset;
    QAction *action_Preview;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QComboBox *serialDeviceCombo;
    QPushButton *connectButton;
    QPushButton *loadFileButton;
    QPushButton *startButton;
    QPushButton *resetButton;
    QPushButton *previewButton;
    QPlainTextEdit *logEdit;
    QHBoxLayout *horizontalLayout_3;
    QLineEdit *sendCommandEdit;
    QPushButton *sendButton;
    QPushButton *clearButton;
    QMenuBar *menuBar;
    QMenu *menu_File;
    QMenu *menu_Tools;
    QMenu *menu_Help;
    QDockWidget *dockWidget;
    QWidget *dockWidgetContents;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QLabel *label_4;
    QFrame *frame_2;
    QLabel *label_5;
    QLabel *label_6;
    QFrame *frame;
    QLabel *label_3;
    QLabel *label_7;
    QLabel *label_8;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton;
    QPushButton *pushButton_8;
    QPushButton *pushButton_26;
    QPushButton *pushButton_7;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QPushButton *pushButton_13;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_21;
    QPushButton *pushButton_22;
    QPushButton *pushButton_23;
    QPushButton *pushButton_24;
    QPushButton *pushButton_25;
    QPushButton *pushButton_29;
    QPushButton *pushButton_30;
    QPushButton *pushButton_31;
    QPushButton *pushButton_32;
    QPushButton *pushButton_33;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *pushButton_17;
    QPushButton *pushButton_2;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton_18;
    QPushButton *pushButton_20;
    QPushButton *pushButton_19;
    QPushButton *pushButton_28;
    QSpacerItem *horizontalSpacer;
    QGroupBox *groupBox_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QSpinBox *spinBox;
    QLabel *label;
    QSpinBox *spinBox_2;
    QSpacerItem *verticalSpacer;
    QDockWidget *previewDock;
    QWidget *dockWidgetContents_3;
    QGridLayout *gridLayout_3;
    QGraphicsView *graphicsView_2;
    QGraphicsView *graphicsView;
    QGraphicsView *graphicsView_3;
    QDockWidget *codeDock;
    QWidget *dockWidgetContents_2;
    QGridLayout *gridLayout_4;
    CodeEditor *textEdit;
    QLabel *timeLabel;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1044, 862);
        actionLoad = new QAction(MainWindow);
        actionLoad->setObjectName(QStringLiteral("actionLoad"));
        action_About = new QAction(MainWindow);
        action_About->setObjectName(QStringLiteral("action_About"));
        action_Settings = new QAction(MainWindow);
        action_Settings->setObjectName(QStringLiteral("action_Settings"));
        action_Reset = new QAction(MainWindow);
        action_Reset->setObjectName(QStringLiteral("action_Reset"));
        action_Preview = new QAction(MainWindow);
        action_Preview->setObjectName(QStringLiteral("action_Preview"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        serialDeviceCombo = new QComboBox(centralWidget);
        serialDeviceCombo->setObjectName(QStringLiteral("serialDeviceCombo"));
        serialDeviceCombo->setEditable(true);

        horizontalLayout_2->addWidget(serialDeviceCombo);

        connectButton = new QPushButton(centralWidget);
        connectButton->setObjectName(QStringLiteral("connectButton"));

        horizontalLayout_2->addWidget(connectButton);

        loadFileButton = new QPushButton(centralWidget);
        loadFileButton->setObjectName(QStringLiteral("loadFileButton"));

        horizontalLayout_2->addWidget(loadFileButton);

        startButton = new QPushButton(centralWidget);
        startButton->setObjectName(QStringLiteral("startButton"));
        startButton->setEnabled(false);

        horizontalLayout_2->addWidget(startButton);

        resetButton = new QPushButton(centralWidget);
        resetButton->setObjectName(QStringLiteral("resetButton"));

        horizontalLayout_2->addWidget(resetButton);

        previewButton = new QPushButton(centralWidget);
        previewButton->setObjectName(QStringLiteral("previewButton"));
        previewButton->setCheckable(true);
        previewButton->setChecked(true);

        horizontalLayout_2->addWidget(previewButton);


        verticalLayout->addLayout(horizontalLayout_2);

        logEdit = new QPlainTextEdit(centralWidget);
        logEdit->setObjectName(QStringLiteral("logEdit"));

        verticalLayout->addWidget(logEdit);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        sendCommandEdit = new QLineEdit(centralWidget);
        sendCommandEdit->setObjectName(QStringLiteral("sendCommandEdit"));

        horizontalLayout_3->addWidget(sendCommandEdit);

        sendButton = new QPushButton(centralWidget);
        sendButton->setObjectName(QStringLiteral("sendButton"));

        horizontalLayout_3->addWidget(sendButton);

        clearButton = new QPushButton(centralWidget);
        clearButton->setObjectName(QStringLiteral("clearButton"));

        horizontalLayout_3->addWidget(clearButton);


        verticalLayout->addLayout(horizontalLayout_3);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1044, 20));
        menu_File = new QMenu(menuBar);
        menu_File->setObjectName(QStringLiteral("menu_File"));
        menu_Tools = new QMenu(menuBar);
        menu_Tools->setObjectName(QStringLiteral("menu_Tools"));
        menu_Help = new QMenu(menuBar);
        menu_Help->setObjectName(QStringLiteral("menu_Help"));
        MainWindow->setMenuBar(menuBar);
        dockWidget = new QDockWidget(MainWindow);
        dockWidget->setObjectName(QStringLiteral("dockWidget"));
        dockWidget->setFeatures(QDockWidget::AllDockWidgetFeatures);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QStringLiteral("dockWidgetContents"));
        gridLayout_2 = new QGridLayout(dockWidgetContents);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label_4 = new QLabel(dockWidgetContents);
        label_4->setObjectName(QStringLiteral("label_4"));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        label_4->setFont(font);
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_4, 10, 5, 1, 2);

        frame_2 = new QFrame(dockWidgetContents);
        frame_2->setObjectName(QStringLiteral("frame_2"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);

        gridLayout->addWidget(frame_2, 5, 5, 1, 2);

        label_5 = new QLabel(dockWidgetContents);
        label_5->setObjectName(QStringLiteral("label_5"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy);
        label_5->setMaximumSize(QSize(35, 16777215));
        label_5->setFont(font);
        label_5->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_5, 1, 14, 1, 1);

        label_6 = new QLabel(dockWidgetContents);
        label_6->setObjectName(QStringLiteral("label_6"));
        sizePolicy.setHeightForWidth(label_6->sizePolicy().hasHeightForWidth());
        label_6->setSizePolicy(sizePolicy);
        label_6->setMaximumSize(QSize(35, 16777215));
        label_6->setFont(font);
        label_6->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_6, 9, 14, 1, 1);

        frame = new QFrame(dockWidgetContents);
        frame->setObjectName(QStringLiteral("frame"));
        sizePolicy.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy);
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);

        gridLayout->addWidget(frame, 5, 14, 1, 1);

        label_3 = new QLabel(dockWidgetContents);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setFont(font);
        label_3->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_3, 0, 5, 1, 2);

        label_7 = new QLabel(dockWidgetContents);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setFont(font);
        label_7->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_7, 5, 0, 1, 1);

        label_8 = new QLabel(dockWidgetContents);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setFont(font);
        label_8->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_8, 5, 11, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 5, 15, 1, 1);

        pushButton = new QPushButton(dockWidgetContents);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy1);
        pushButton->setMinimumSize(QSize(35, 35));
        pushButton->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton, 4, 5, 1, 2);

        pushButton_8 = new QPushButton(dockWidgetContents);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        sizePolicy1.setHeightForWidth(pushButton_8->sizePolicy().hasHeightForWidth());
        pushButton_8->setSizePolicy(sizePolicy1);
        pushButton_8->setMinimumSize(QSize(35, 35));
        pushButton_8->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_8, 5, 10, 1, 1);

        pushButton_26 = new QPushButton(dockWidgetContents);
        pushButton_26->setObjectName(QStringLiteral("pushButton_26"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(pushButton_26->sizePolicy().hasHeightForWidth());
        pushButton_26->setSizePolicy(sizePolicy2);
        pushButton_26->setMinimumSize(QSize(35, 35));
        pushButton_26->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_26, 8, 14, 1, 1);

        pushButton_7 = new QPushButton(dockWidgetContents);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        sizePolicy1.setHeightForWidth(pushButton_7->sizePolicy().hasHeightForWidth());
        pushButton_7->setSizePolicy(sizePolicy1);
        pushButton_7->setMinimumSize(QSize(35, 35));
        pushButton_7->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_7, 1, 5, 1, 2);

        pushButton_9 = new QPushButton(dockWidgetContents);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        sizePolicy1.setHeightForWidth(pushButton_9->sizePolicy().hasHeightForWidth());
        pushButton_9->setSizePolicy(sizePolicy1);
        pushButton_9->setMinimumSize(QSize(35, 35));
        pushButton_9->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_9, 2, 5, 1, 2);

        pushButton_10 = new QPushButton(dockWidgetContents);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        sizePolicy1.setHeightForWidth(pushButton_10->sizePolicy().hasHeightForWidth());
        pushButton_10->setSizePolicy(sizePolicy1);
        pushButton_10->setMinimumSize(QSize(35, 35));
        pushButton_10->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_10, 3, 5, 1, 2);

        pushButton_13 = new QPushButton(dockWidgetContents);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        sizePolicy1.setHeightForWidth(pushButton_13->sizePolicy().hasHeightForWidth());
        pushButton_13->setSizePolicy(sizePolicy1);
        pushButton_13->setMinimumSize(QSize(35, 35));
        pushButton_13->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_13, 5, 4, 1, 1);

        pushButton_14 = new QPushButton(dockWidgetContents);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        sizePolicy1.setHeightForWidth(pushButton_14->sizePolicy().hasHeightForWidth());
        pushButton_14->setSizePolicy(sizePolicy1);
        pushButton_14->setMinimumSize(QSize(35, 35));
        pushButton_14->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_14, 5, 3, 1, 1);

        pushButton_15 = new QPushButton(dockWidgetContents);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        sizePolicy1.setHeightForWidth(pushButton_15->sizePolicy().hasHeightForWidth());
        pushButton_15->setSizePolicy(sizePolicy1);
        pushButton_15->setMinimumSize(QSize(35, 35));
        pushButton_15->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_15, 5, 2, 1, 1);

        pushButton_16 = new QPushButton(dockWidgetContents);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        sizePolicy1.setHeightForWidth(pushButton_16->sizePolicy().hasHeightForWidth());
        pushButton_16->setSizePolicy(sizePolicy1);
        pushButton_16->setMinimumSize(QSize(35, 35));
        pushButton_16->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_16, 5, 1, 1, 1);

        pushButton_11 = new QPushButton(dockWidgetContents);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        sizePolicy1.setHeightForWidth(pushButton_11->sizePolicy().hasHeightForWidth());
        pushButton_11->setSizePolicy(sizePolicy1);
        pushButton_11->setMinimumSize(QSize(35, 35));
        pushButton_11->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_11, 5, 7, 1, 1);

        pushButton_12 = new QPushButton(dockWidgetContents);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        sizePolicy1.setHeightForWidth(pushButton_12->sizePolicy().hasHeightForWidth());
        pushButton_12->setSizePolicy(sizePolicy1);
        pushButton_12->setMinimumSize(QSize(35, 35));
        pushButton_12->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_12, 5, 8, 1, 1);

        pushButton_21 = new QPushButton(dockWidgetContents);
        pushButton_21->setObjectName(QStringLiteral("pushButton_21"));
        sizePolicy1.setHeightForWidth(pushButton_21->sizePolicy().hasHeightForWidth());
        pushButton_21->setSizePolicy(sizePolicy1);
        pushButton_21->setMinimumSize(QSize(35, 35));
        pushButton_21->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_21, 5, 9, 1, 1);

        pushButton_22 = new QPushButton(dockWidgetContents);
        pushButton_22->setObjectName(QStringLiteral("pushButton_22"));
        sizePolicy1.setHeightForWidth(pushButton_22->sizePolicy().hasHeightForWidth());
        pushButton_22->setSizePolicy(sizePolicy1);
        pushButton_22->setMinimumSize(QSize(35, 35));
        pushButton_22->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_22, 6, 5, 1, 2);

        pushButton_23 = new QPushButton(dockWidgetContents);
        pushButton_23->setObjectName(QStringLiteral("pushButton_23"));
        sizePolicy1.setHeightForWidth(pushButton_23->sizePolicy().hasHeightForWidth());
        pushButton_23->setSizePolicy(sizePolicy1);
        pushButton_23->setMinimumSize(QSize(35, 35));
        pushButton_23->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_23, 7, 5, 1, 2);

        pushButton_24 = new QPushButton(dockWidgetContents);
        pushButton_24->setObjectName(QStringLiteral("pushButton_24"));
        sizePolicy1.setHeightForWidth(pushButton_24->sizePolicy().hasHeightForWidth());
        pushButton_24->setSizePolicy(sizePolicy1);
        pushButton_24->setMinimumSize(QSize(35, 35));
        pushButton_24->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_24, 8, 5, 1, 2);

        pushButton_25 = new QPushButton(dockWidgetContents);
        pushButton_25->setObjectName(QStringLiteral("pushButton_25"));
        sizePolicy1.setHeightForWidth(pushButton_25->sizePolicy().hasHeightForWidth());
        pushButton_25->setSizePolicy(sizePolicy1);
        pushButton_25->setMinimumSize(QSize(35, 35));
        pushButton_25->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_25, 9, 5, 1, 2);

        pushButton_29 = new QPushButton(dockWidgetContents);
        pushButton_29->setObjectName(QStringLiteral("pushButton_29"));
        sizePolicy2.setHeightForWidth(pushButton_29->sizePolicy().hasHeightForWidth());
        pushButton_29->setSizePolicy(sizePolicy2);
        pushButton_29->setMinimumSize(QSize(35, 35));
        pushButton_29->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_29, 6, 14, 1, 1);

        pushButton_30 = new QPushButton(dockWidgetContents);
        pushButton_30->setObjectName(QStringLiteral("pushButton_30"));
        sizePolicy2.setHeightForWidth(pushButton_30->sizePolicy().hasHeightForWidth());
        pushButton_30->setSizePolicy(sizePolicy2);
        pushButton_30->setMinimumSize(QSize(35, 35));
        pushButton_30->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_30, 7, 14, 1, 1);

        pushButton_31 = new QPushButton(dockWidgetContents);
        pushButton_31->setObjectName(QStringLiteral("pushButton_31"));
        sizePolicy2.setHeightForWidth(pushButton_31->sizePolicy().hasHeightForWidth());
        pushButton_31->setSizePolicy(sizePolicy2);
        pushButton_31->setMinimumSize(QSize(35, 35));
        pushButton_31->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_31, 4, 14, 1, 1);

        pushButton_32 = new QPushButton(dockWidgetContents);
        pushButton_32->setObjectName(QStringLiteral("pushButton_32"));
        sizePolicy2.setHeightForWidth(pushButton_32->sizePolicy().hasHeightForWidth());
        pushButton_32->setSizePolicy(sizePolicy2);
        pushButton_32->setMinimumSize(QSize(35, 35));
        pushButton_32->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_32, 3, 14, 1, 1);

        pushButton_33 = new QPushButton(dockWidgetContents);
        pushButton_33->setObjectName(QStringLiteral("pushButton_33"));
        sizePolicy2.setHeightForWidth(pushButton_33->sizePolicy().hasHeightForWidth());
        pushButton_33->setSizePolicy(sizePolicy2);
        pushButton_33->setMinimumSize(QSize(35, 35));
        pushButton_33->setMaximumSize(QSize(35, 35));

        gridLayout->addWidget(pushButton_33, 2, 14, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 5, 12, 1, 2);


        gridLayout_2->addLayout(gridLayout, 1, 0, 1, 1);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        pushButton_17 = new QPushButton(dockWidgetContents);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(pushButton_17->sizePolicy().hasHeightForWidth());
        pushButton_17->setSizePolicy(sizePolicy3);

        horizontalLayout_5->addWidget(pushButton_17);

        pushButton_2 = new QPushButton(dockWidgetContents);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        sizePolicy3.setHeightForWidth(pushButton_2->sizePolicy().hasHeightForWidth());
        pushButton_2->setSizePolicy(sizePolicy3);

        horizontalLayout_5->addWidget(pushButton_2);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        pushButton_18 = new QPushButton(dockWidgetContents);
        pushButton_18->setObjectName(QStringLiteral("pushButton_18"));

        verticalLayout_2->addWidget(pushButton_18);

        pushButton_20 = new QPushButton(dockWidgetContents);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));

        verticalLayout_2->addWidget(pushButton_20);

        pushButton_19 = new QPushButton(dockWidgetContents);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));

        verticalLayout_2->addWidget(pushButton_19);


        horizontalLayout_4->addLayout(verticalLayout_2);

        pushButton_28 = new QPushButton(dockWidgetContents);
        pushButton_28->setObjectName(QStringLiteral("pushButton_28"));
        sizePolicy3.setHeightForWidth(pushButton_28->sizePolicy().hasHeightForWidth());
        pushButton_28->setSizePolicy(sizePolicy3);

        horizontalLayout_4->addWidget(pushButton_28);


        horizontalLayout_5->addLayout(horizontalLayout_4);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer);

        groupBox_2 = new QGroupBox(dockWidgetContents);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        horizontalLayout = new QHBoxLayout(groupBox_2);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout->addWidget(label_2);

        spinBox = new QSpinBox(groupBox_2);
        spinBox->setObjectName(QStringLiteral("spinBox"));
        spinBox->setMinimum(1);
        spinBox->setMaximum(1000);
        spinBox->setValue(50);

        horizontalLayout->addWidget(spinBox);

        label = new QLabel(groupBox_2);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);

        spinBox_2 = new QSpinBox(groupBox_2);
        spinBox_2->setObjectName(QStringLiteral("spinBox_2"));
        spinBox_2->setMinimum(1);
        spinBox_2->setMaximum(1000);
        spinBox_2->setValue(50);

        horizontalLayout->addWidget(spinBox_2);


        horizontalLayout_5->addWidget(groupBox_2);


        gridLayout_2->addLayout(horizontalLayout_5, 0, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer, 2, 0, 1, 1);

        dockWidget->setWidget(dockWidgetContents);
        MainWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(1), dockWidget);
        previewDock = new QDockWidget(MainWindow);
        previewDock->setObjectName(QStringLiteral("previewDock"));
        previewDock->setFeatures(QDockWidget::AllDockWidgetFeatures);
        dockWidgetContents_3 = new QWidget();
        dockWidgetContents_3->setObjectName(QStringLiteral("dockWidgetContents_3"));
        gridLayout_3 = new QGridLayout(dockWidgetContents_3);
        gridLayout_3->setSpacing(0);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        graphicsView_2 = new QGraphicsView(dockWidgetContents_3);
        graphicsView_2->setObjectName(QStringLiteral("graphicsView_2"));
        graphicsView_2->setMaximumSize(QSize(16777215, 20));
        graphicsView_2->setFrameShape(QFrame::NoFrame);

        gridLayout_3->addWidget(graphicsView_2, 1, 1, 1, 1);

        graphicsView = new QGraphicsView(dockWidgetContents_3);
        graphicsView->setObjectName(QStringLiteral("graphicsView"));
        graphicsView->setFrameShape(QFrame::NoFrame);

        gridLayout_3->addWidget(graphicsView, 0, 1, 1, 1);

        graphicsView_3 = new QGraphicsView(dockWidgetContents_3);
        graphicsView_3->setObjectName(QStringLiteral("graphicsView_3"));
        graphicsView_3->setMaximumSize(QSize(20, 16777215));
        graphicsView_3->setFrameShape(QFrame::NoFrame);

        gridLayout_3->addWidget(graphicsView_3, 0, 0, 1, 1);

        previewDock->setWidget(dockWidgetContents_3);
        MainWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(1), previewDock);
        codeDock = new QDockWidget(MainWindow);
        codeDock->setObjectName(QStringLiteral("codeDock"));
        dockWidgetContents_2 = new QWidget();
        dockWidgetContents_2->setObjectName(QStringLiteral("dockWidgetContents_2"));
        gridLayout_4 = new QGridLayout(dockWidgetContents_2);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        textEdit = new CodeEditor(dockWidgetContents_2);
        textEdit->setObjectName(QStringLiteral("textEdit"));

        gridLayout_4->addWidget(textEdit, 0, 0, 1, 1);

        timeLabel = new QLabel(dockWidgetContents_2);
        timeLabel->setObjectName(QStringLiteral("timeLabel"));

        gridLayout_4->addWidget(timeLabel, 1, 0, 1, 1);

        codeDock->setWidget(dockWidgetContents_2);
        MainWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(1), codeDock);

        menuBar->addAction(menu_File->menuAction());
        menuBar->addAction(menu_Tools->menuAction());
        menuBar->addAction(menu_Help->menuAction());
        menu_File->addAction(actionLoad);
        menu_Tools->addAction(action_Settings);
        menu_Tools->addAction(action_Reset);
        menu_Tools->addAction(action_Preview);
        menu_Help->addAction(action_About);

        retranslateUi(MainWindow);
        QObject::connect(sendCommandEdit, SIGNAL(returnPressed()), sendButton, SLOT(click()));
        QObject::connect(clearButton, SIGNAL(clicked()), logEdit, SLOT(clear()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        actionLoad->setText(QApplication::translate("MainWindow", "&Load...", 0));
        action_About->setText(QApplication::translate("MainWindow", "&About...", 0));
        action_Settings->setText(QApplication::translate("MainWindow", "&Settings", 0));
        action_Reset->setText(QApplication::translate("MainWindow", "&Reset", 0));
        action_Preview->setText(QApplication::translate("MainWindow", "&Preview", 0));
        serialDeviceCombo->clear();
        serialDeviceCombo->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "/dev/ttyACM0", 0)
         << QApplication::translate("MainWindow", "/dev/ttyACM1", 0)
         << QApplication::translate("MainWindow", "/dev/ttyACM2", 0)
        );
        connectButton->setText(QApplication::translate("MainWindow", "&Connect", 0));
        loadFileButton->setText(QApplication::translate("MainWindow", "&Load Test", 0));
        startButton->setText(QApplication::translate("MainWindow", "&Start", 0));
        resetButton->setText(QApplication::translate("MainWindow", "&Reset", 0));
        previewButton->setText(QApplication::translate("MainWindow", "&Preview", 0));
        sendButton->setText(QApplication::translate("MainWindow", "Send", 0));
        clearButton->setText(QApplication::translate("MainWindow", "Clear", 0));
        menu_File->setTitle(QApplication::translate("MainWindow", "&File", 0));
        menu_Tools->setTitle(QApplication::translate("MainWindow", "&Tools", 0));
        menu_Help->setTitle(QApplication::translate("MainWindow", "&Help", 0));
        dockWidget->setWindowTitle(QApplication::translate("MainWindow", "Control", 0));
        label_4->setText(QApplication::translate("MainWindow", "y-", 0));
        label_5->setText(QApplication::translate("MainWindow", "z+", 0));
        label_6->setText(QApplication::translate("MainWindow", "z-", 0));
        label_3->setText(QApplication::translate("MainWindow", "y+", 0));
        label_7->setText(QApplication::translate("MainWindow", "x-", 0));
        label_8->setText(QApplication::translate("MainWindow", "x+", 0));
        pushButton->setText(QApplication::translate("MainWindow", "0.1", 0));
        pushButton_8->setText(QApplication::translate("MainWindow", "100", 0));
        pushButton_26->setText(QApplication::translate("MainWindow", "10", 0));
        pushButton_7->setText(QApplication::translate("MainWindow", "100", 0));
        pushButton_9->setText(QApplication::translate("MainWindow", "10", 0));
        pushButton_10->setText(QApplication::translate("MainWindow", "1", 0));
        pushButton_13->setText(QApplication::translate("MainWindow", "0.1", 0));
        pushButton_14->setText(QApplication::translate("MainWindow", "1", 0));
        pushButton_15->setText(QApplication::translate("MainWindow", "10", 0));
        pushButton_16->setText(QApplication::translate("MainWindow", "100", 0));
        pushButton_11->setText(QApplication::translate("MainWindow", "0.1", 0));
        pushButton_12->setText(QApplication::translate("MainWindow", "1", 0));
        pushButton_21->setText(QApplication::translate("MainWindow", "10", 0));
        pushButton_22->setText(QApplication::translate("MainWindow", "0.1", 0));
        pushButton_23->setText(QApplication::translate("MainWindow", "1", 0));
        pushButton_24->setText(QApplication::translate("MainWindow", "10", 0));
        pushButton_25->setText(QApplication::translate("MainWindow", "100", 0));
        pushButton_29->setText(QApplication::translate("MainWindow", "0.1", 0));
        pushButton_30->setText(QApplication::translate("MainWindow", "1", 0));
        pushButton_31->setText(QApplication::translate("MainWindow", "0.1", 0));
        pushButton_32->setText(QApplication::translate("MainWindow", "1", 0));
        pushButton_33->setText(QApplication::translate("MainWindow", "10", 0));
        pushButton_17->setText(QApplication::translate("MainWindow", "&Stop", 0));
        pushButton_2->setText(QApplication::translate("MainWindow", "Test", 0));
        pushButton_18->setText(QApplication::translate("MainWindow", "Home &x", 0));
        pushButton_20->setText(QApplication::translate("MainWindow", "Home &y", 0));
        pushButton_19->setText(QApplication::translate("MainWindow", "Home &z", 0));
        pushButton_28->setText(QApplication::translate("MainWindow", "Home &all", 0));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Feed rate", 0));
        label_2->setText(QApplication::translate("MainWindow", "X-Y:", 0));
        spinBox->setSuffix(QApplication::translate("MainWindow", " mm/s", 0));
        label->setText(QApplication::translate("MainWindow", "Z:", 0));
        spinBox_2->setSuffix(QApplication::translate("MainWindow", " mm/s", 0));
        previewDock->setWindowTitle(QApplication::translate("MainWindow", "Preview", 0));
        codeDock->setWindowTitle(QApplication::translate("MainWindow", "GCode", 0));
        timeLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
