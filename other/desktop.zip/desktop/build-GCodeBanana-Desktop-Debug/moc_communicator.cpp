/****************************************************************************
** Meta object code from reading C++ file 'communicator.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../GCodeBanana/communicator.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'communicator.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Communicator_t {
    QByteArrayData data[13];
    char stringdata[173];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_Communicator_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_Communicator_t qt_meta_stringdata_Communicator = {
    {
QT_MOC_LITERAL(0, 0, 12),
QT_MOC_LITERAL(1, 13, 12),
QT_MOC_LITERAL(2, 26, 0),
QT_MOC_LITERAL(3, 27, 15),
QT_MOC_LITERAL(4, 43, 15),
QT_MOC_LITERAL(5, 59, 7),
QT_MOC_LITERAL(6, 67, 7),
QT_MOC_LITERAL(7, 75, 16),
QT_MOC_LITERAL(8, 92, 12),
QT_MOC_LITERAL(9, 105, 16),
QT_MOC_LITERAL(10, 122, 17),
QT_MOC_LITERAL(11, 140, 13),
QT_MOC_LITERAL(12, 154, 17)
    },
    "Communicator\0usbConnected\0\0usbDisconnected\0"
    "commandReceived\0command\0usbTask\0"
    "ActiveConnection\0NoConnection\0"
    "SerialConnection\0NetworkConnection\0"
    "UsbConnection\0ActiveConnections\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Communicator[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       2,   40, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   34,    2, 0x05,
       3,    0,   35,    2, 0x05,
       4,    1,   36,    2, 0x05,

 // slots: name, argc, parameters, tag, flags
       6,    0,   39,    2, 0x08,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QByteArray,    5,

 // slots: parameters
    QMetaType::Void,

 // enums: name, flags, count, data
       7, 0x1,    4,   48,
      12, 0x1,    4,   56,

 // enum data: key, value
       8, uint(Communicator::NoConnection),
       9, uint(Communicator::SerialConnection),
      10, uint(Communicator::NetworkConnection),
      11, uint(Communicator::UsbConnection),
       8, uint(Communicator::NoConnection),
       9, uint(Communicator::SerialConnection),
      10, uint(Communicator::NetworkConnection),
      11, uint(Communicator::UsbConnection),

       0        // eod
};

void Communicator::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Communicator *_t = static_cast<Communicator *>(_o);
        switch (_id) {
        case 0: _t->usbConnected(); break;
        case 1: _t->usbDisconnected(); break;
        case 2: _t->commandReceived((*reinterpret_cast< const QByteArray(*)>(_a[1]))); break;
        case 3: _t->usbTask(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Communicator::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Communicator::usbConnected)) {
                *result = 0;
            }
        }
        {
            typedef void (Communicator::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Communicator::usbDisconnected)) {
                *result = 1;
            }
        }
        {
            typedef void (Communicator::*_t)(const QByteArray );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Communicator::commandReceived)) {
                *result = 2;
            }
        }
    }
}

const QMetaObject Communicator::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Communicator.data,
      qt_meta_data_Communicator,  qt_static_metacall, 0, 0}
};


const QMetaObject *Communicator::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Communicator::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Communicator.stringdata))
        return static_cast<void*>(const_cast< Communicator*>(this));
    return QObject::qt_metacast(_clname);
}

int Communicator::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
    return _id;
}

// SIGNAL 0
void Communicator::usbConnected()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void Communicator::usbDisconnected()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void Communicator::commandReceived(const QByteArray _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_END_MOC_NAMESPACE
