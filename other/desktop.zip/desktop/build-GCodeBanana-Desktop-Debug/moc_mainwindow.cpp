/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../GCodeBanana/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[49];
    char stringdata[1040];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_MainWindow_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 11),
QT_MOC_LITERAL(2, 23, 0),
QT_MOC_LITERAL(3, 24, 5),
QT_MOC_LITERAL(4, 30, 14),
QT_MOC_LITERAL(5, 45, 12),
QT_MOC_LITERAL(6, 58, 15),
QT_MOC_LITERAL(7, 74, 24),
QT_MOC_LITERAL(8, 99, 3),
QT_MOC_LITERAL(9, 103, 25),
QT_MOC_LITERAL(10, 129, 21),
QT_MOC_LITERAL(11, 151, 5),
QT_MOC_LITERAL(12, 157, 14),
QT_MOC_LITERAL(13, 172, 25),
QT_MOC_LITERAL(14, 198, 24),
QT_MOC_LITERAL(15, 223, 24),
QT_MOC_LITERAL(16, 248, 21),
QT_MOC_LITERAL(17, 270, 24),
QT_MOC_LITERAL(18, 295, 24),
QT_MOC_LITERAL(19, 320, 23),
QT_MOC_LITERAL(20, 344, 24),
QT_MOC_LITERAL(21, 369, 24),
QT_MOC_LITERAL(22, 394, 24),
QT_MOC_LITERAL(23, 419, 24),
QT_MOC_LITERAL(24, 444, 21),
QT_MOC_LITERAL(25, 466, 24),
QT_MOC_LITERAL(26, 491, 23),
QT_MOC_LITERAL(27, 515, 23),
QT_MOC_LITERAL(28, 539, 24),
QT_MOC_LITERAL(29, 564, 24),
QT_MOC_LITERAL(30, 589, 24),
QT_MOC_LITERAL(31, 614, 24),
QT_MOC_LITERAL(32, 639, 24),
QT_MOC_LITERAL(33, 664, 24),
QT_MOC_LITERAL(34, 689, 24),
QT_MOC_LITERAL(35, 714, 24),
QT_MOC_LITERAL(36, 739, 24),
QT_MOC_LITERAL(37, 764, 24),
QT_MOC_LITERAL(38, 789, 24),
QT_MOC_LITERAL(39, 814, 24),
QT_MOC_LITERAL(40, 839, 24),
QT_MOC_LITERAL(41, 864, 24),
QT_MOC_LITERAL(42, 889, 23),
QT_MOC_LITERAL(43, 913, 4),
QT_MOC_LITERAL(44, 918, 25),
QT_MOC_LITERAL(45, 944, 24),
QT_MOC_LITERAL(46, 969, 23),
QT_MOC_LITERAL(47, 993, 22),
QT_MOC_LITERAL(48, 1016, 22)
    },
    "MainWindow\0codeChanged\0\0valid\0"
    "refreshPreview\0usbConnected\0usbDisconnected\0"
    "workerCurrentLineChanged\0arg\0"
    "workerCurrentStateChanged\0"
    "Worker::WorkingStates\0state\0workerFinished\0"
    "on_loadFileButton_clicked\0"
    "on_connectButton_clicked\0"
    "on_pushButton_11_clicked\0on_sendButton_clicked\0"
    "on_pushButton_12_clicked\0"
    "on_pushButton_21_clicked\0"
    "on_pushButton_8_clicked\0"
    "on_pushButton_13_clicked\0"
    "on_pushButton_14_clicked\0"
    "on_pushButton_15_clicked\0"
    "on_pushButton_16_clicked\0on_pushButton_clicked\0"
    "on_pushButton_10_clicked\0"
    "on_pushButton_9_clicked\0on_pushButton_7_clicked\0"
    "on_pushButton_22_clicked\0"
    "on_pushButton_23_clicked\0"
    "on_pushButton_24_clicked\0"
    "on_pushButton_25_clicked\0"
    "on_pushButton_31_clicked\0"
    "on_pushButton_32_clicked\0"
    "on_pushButton_33_clicked\0"
    "on_pushButton_29_clicked\0"
    "on_pushButton_30_clicked\0"
    "on_pushButton_26_clicked\0"
    "on_pushButton_18_clicked\0"
    "on_pushButton_20_clicked\0"
    "on_pushButton_19_clicked\0"
    "on_pushButton_28_clicked\0"
    "on_spinBox_valueChanged\0arg1\0"
    "on_spinBox_2_valueChanged\0"
    "on_pushButton_17_clicked\0"
    "on_pushButton_2_clicked\0on_startButton_clicked\0"
    "on_resetButton_clicked\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      42,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  224,    2, 0x08,
       4,    0,  227,    2, 0x08,
       5,    0,  228,    2, 0x08,
       6,    0,  229,    2, 0x08,
       7,    1,  230,    2, 0x08,
       9,    1,  233,    2, 0x08,
      12,    0,  236,    2, 0x08,
      13,    0,  237,    2, 0x08,
      14,    0,  238,    2, 0x08,
      15,    0,  239,    2, 0x08,
      16,    0,  240,    2, 0x08,
      17,    0,  241,    2, 0x08,
      18,    0,  242,    2, 0x08,
      19,    0,  243,    2, 0x08,
      20,    0,  244,    2, 0x08,
      21,    0,  245,    2, 0x08,
      22,    0,  246,    2, 0x08,
      23,    0,  247,    2, 0x08,
      24,    0,  248,    2, 0x08,
      25,    0,  249,    2, 0x08,
      26,    0,  250,    2, 0x08,
      27,    0,  251,    2, 0x08,
      28,    0,  252,    2, 0x08,
      29,    0,  253,    2, 0x08,
      30,    0,  254,    2, 0x08,
      31,    0,  255,    2, 0x08,
      32,    0,  256,    2, 0x08,
      33,    0,  257,    2, 0x08,
      34,    0,  258,    2, 0x08,
      35,    0,  259,    2, 0x08,
      36,    0,  260,    2, 0x08,
      37,    0,  261,    2, 0x08,
      38,    0,  262,    2, 0x08,
      39,    0,  263,    2, 0x08,
      40,    0,  264,    2, 0x08,
      41,    0,  265,    2, 0x08,
      42,    1,  266,    2, 0x08,
      44,    1,  269,    2, 0x08,
      45,    0,  272,    2, 0x08,
      46,    0,  273,    2, 0x08,
      47,    0,  274,    2, 0x08,
      48,    0,  275,    2, 0x08,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   43,
    QMetaType::Void, QMetaType::Int,   43,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->codeChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->refreshPreview(); break;
        case 2: _t->usbConnected(); break;
        case 3: _t->usbDisconnected(); break;
        case 4: _t->workerCurrentLineChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->workerCurrentStateChanged((*reinterpret_cast< Worker::WorkingStates(*)>(_a[1]))); break;
        case 6: _t->workerFinished(); break;
        case 7: _t->on_loadFileButton_clicked(); break;
        case 8: _t->on_connectButton_clicked(); break;
        case 9: _t->on_pushButton_11_clicked(); break;
        case 10: _t->on_sendButton_clicked(); break;
        case 11: _t->on_pushButton_12_clicked(); break;
        case 12: _t->on_pushButton_21_clicked(); break;
        case 13: _t->on_pushButton_8_clicked(); break;
        case 14: _t->on_pushButton_13_clicked(); break;
        case 15: _t->on_pushButton_14_clicked(); break;
        case 16: _t->on_pushButton_15_clicked(); break;
        case 17: _t->on_pushButton_16_clicked(); break;
        case 18: _t->on_pushButton_clicked(); break;
        case 19: _t->on_pushButton_10_clicked(); break;
        case 20: _t->on_pushButton_9_clicked(); break;
        case 21: _t->on_pushButton_7_clicked(); break;
        case 22: _t->on_pushButton_22_clicked(); break;
        case 23: _t->on_pushButton_23_clicked(); break;
        case 24: _t->on_pushButton_24_clicked(); break;
        case 25: _t->on_pushButton_25_clicked(); break;
        case 26: _t->on_pushButton_31_clicked(); break;
        case 27: _t->on_pushButton_32_clicked(); break;
        case 28: _t->on_pushButton_33_clicked(); break;
        case 29: _t->on_pushButton_29_clicked(); break;
        case 30: _t->on_pushButton_30_clicked(); break;
        case 31: _t->on_pushButton_26_clicked(); break;
        case 32: _t->on_pushButton_18_clicked(); break;
        case 33: _t->on_pushButton_20_clicked(); break;
        case 34: _t->on_pushButton_19_clicked(); break;
        case 35: _t->on_pushButton_28_clicked(); break;
        case 36: _t->on_spinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 37: _t->on_spinBox_2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 38: _t->on_pushButton_17_clicked(); break;
        case 39: _t->on_pushButton_2_clicked(); break;
        case 40: _t->on_startButton_clicked(); break;
        case 41: _t->on_resetButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, 0, 0}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 42)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 42;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 42)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 42;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
