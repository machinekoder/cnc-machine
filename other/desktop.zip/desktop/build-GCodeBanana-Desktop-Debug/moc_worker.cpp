/****************************************************************************
** Meta object code from reading C++ file 'worker.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../GCodeBanana/worker.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'worker.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Worker_t {
    QByteArrayData data[26];
    char stringdata[336];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_Worker_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_Worker_t qt_meta_stringdata_Worker = {
    {
QT_MOC_LITERAL(0, 0, 6),
QT_MOC_LITERAL(1, 7, 8),
QT_MOC_LITERAL(2, 16, 0),
QT_MOC_LITERAL(3, 17, 18),
QT_MOC_LITERAL(4, 36, 3),
QT_MOC_LITERAL(5, 40, 18),
QT_MOC_LITERAL(6, 59, 12),
QT_MOC_LITERAL(7, 72, 19),
QT_MOC_LITERAL(8, 92, 21),
QT_MOC_LITERAL(9, 114, 17),
QT_MOC_LITERAL(10, 132, 14),
QT_MOC_LITERAL(11, 147, 13),
QT_MOC_LITERAL(12, 161, 12),
QT_MOC_LITERAL(13, 174, 15),
QT_MOC_LITERAL(14, 190, 15),
QT_MOC_LITERAL(15, 206, 7),
QT_MOC_LITERAL(16, 214, 14),
QT_MOC_LITERAL(17, 229, 11),
QT_MOC_LITERAL(18, 241, 11),
QT_MOC_LITERAL(19, 253, 5),
QT_MOC_LITERAL(20, 259, 12),
QT_MOC_LITERAL(21, 272, 13),
QT_MOC_LITERAL(22, 286, 10),
QT_MOC_LITERAL(23, 297, 12),
QT_MOC_LITERAL(24, 310, 12),
QT_MOC_LITERAL(25, 323, 11)
    },
    "Worker\0finished\0\0commandListChanged\0"
    "arg\0currentLineChanged\0readyChanged\0"
    "currentStateChanged\0Worker::WorkingStates\0"
    "bufferSizeChanged\0setCommandList\0"
    "setBufferSize\0usbConnected\0usbDisconnected\0"
    "commandReceived\0command\0aliveTimerTick\0"
    "commandList\0currentLine\0ready\0"
    "currentState\0WorkingStates\0bufferSize\0"
    "StoppedState\0RunningState\0PausedState\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Worker[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       5,  102, // properties
       1,  122, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x05,
       3,    1,   75,    2, 0x05,
       5,    1,   78,    2, 0x05,
       6,    1,   81,    2, 0x05,
       7,    1,   84,    2, 0x05,
       9,    1,   87,    2, 0x05,

 // slots: name, argc, parameters, tag, flags
      10,    1,   90,    2, 0x0a,
      11,    1,   93,    2, 0x0a,
      12,    0,   96,    2, 0x08,
      13,    0,   97,    2, 0x08,
      14,    1,   98,    2, 0x08,
      16,    0,  101,    2, 0x08,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QStringList,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, 0x80000000 | 8,    4,
    QMetaType::Void, QMetaType::Int,    4,

 // slots: parameters
    QMetaType::Void, QMetaType::QStringList,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QByteArray,   15,
    QMetaType::Void,

 // properties: name, type, flags
      17, QMetaType::QStringList, 0x00495103,
      18, QMetaType::Int, 0x00495001,
      19, QMetaType::Bool, 0x00495001,
      20, 0x80000000 | 21, 0x00495009,
      22, QMetaType::Int, 0x00495103,

 // properties: notify_signal_id
       1,
       2,
       3,
       4,
       5,

 // enums: name, flags, count, data
      21, 0x0,    3,  126,

 // enum data: key, value
      23, uint(Worker::StoppedState),
      24, uint(Worker::RunningState),
      25, uint(Worker::PausedState),

       0        // eod
};

void Worker::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Worker *_t = static_cast<Worker *>(_o);
        switch (_id) {
        case 0: _t->finished(); break;
        case 1: _t->commandListChanged((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 2: _t->currentLineChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->readyChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->currentStateChanged((*reinterpret_cast< Worker::WorkingStates(*)>(_a[1]))); break;
        case 5: _t->bufferSizeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->setCommandList((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 7: _t->setBufferSize((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->usbConnected(); break;
        case 9: _t->usbDisconnected(); break;
        case 10: _t->commandReceived((*reinterpret_cast< const QByteArray(*)>(_a[1]))); break;
        case 11: _t->aliveTimerTick(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Worker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Worker::finished)) {
                *result = 0;
            }
        }
        {
            typedef void (Worker::*_t)(QStringList );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Worker::commandListChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (Worker::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Worker::currentLineChanged)) {
                *result = 2;
            }
        }
        {
            typedef void (Worker::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Worker::readyChanged)) {
                *result = 3;
            }
        }
        {
            typedef void (Worker::*_t)(Worker::WorkingStates );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Worker::currentStateChanged)) {
                *result = 4;
            }
        }
        {
            typedef void (Worker::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Worker::bufferSizeChanged)) {
                *result = 5;
            }
        }
    }
}

const QMetaObject Worker::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Worker.data,
      qt_meta_data_Worker,  qt_static_metacall, 0, 0}
};


const QMetaObject *Worker::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Worker::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Worker.stringdata))
        return static_cast<void*>(const_cast< Worker*>(this));
    return QObject::qt_metacast(_clname);
}

int Worker::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QStringList*>(_v) = commandList(); break;
        case 1: *reinterpret_cast< int*>(_v) = currentLine(); break;
        case 2: *reinterpret_cast< bool*>(_v) = isReady(); break;
        case 3: *reinterpret_cast< WorkingStates*>(_v) = currentState(); break;
        case 4: *reinterpret_cast< int*>(_v) = bufferSize(); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setCommandList(*reinterpret_cast< QStringList*>(_v)); break;
        case 4: setBufferSize(*reinterpret_cast< int*>(_v)); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void Worker::finished()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void Worker::commandListChanged(QStringList _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Worker::currentLineChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Worker::readyChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Worker::currentStateChanged(Worker::WorkingStates _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Worker::bufferSizeChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_END_MOC_NAMESPACE
