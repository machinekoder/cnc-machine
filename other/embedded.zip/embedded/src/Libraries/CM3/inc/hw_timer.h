#ifndef _hw_timer_h_
#define _hw_timer_h_

char TimerInit(char timer);
char TimerStart();
char TimerResetStop();
char TimerClrIRFlag();

#endif
